from flask import Flask, render_template, request, redirect, url_for, jsonify, make_response, session, flash
from pymongo import MongoClient
import pandas as pd
from datetime import datetime
import json
from bson import ObjectId
import io
import csv
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import smtplib
import email.mime.text as mime_text
import email.mime.multipart as mime_multipart
import secrets

app = Flask(__name__)
app.secret_key = 'bharath_ladies_pg_secret_key_2025'  

# Email configuration
ADMIN_EMAIL = 'sumiyasum1904@gmail.com'
SMTP_SERVER = 'smtp.gmail.com'
SMTP_PORT = 587
# You'll need to set up an app password for Gmail
SMTP_USERNAME = 'your_email@gmail.com'  
SMTP_PASSWORD = 'your_app_password'  
EMAIL_ENABLED = False  # Set to True when email is configured

# MongoDB connection
client = MongoClient('mongodb://localhost:27017/')
db = client['bharath_ladies_pg']
collection = db['residents']
users_collection = db['users']

class JSONEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, ObjectId):
            return str(o)
        return json.JSONEncoder.default(self, o)

app.json_encoder = JSONEncoder

# Email functions
def send_email(to_email, subject, body):
    if not EMAIL_ENABLED:
        print(f"Email disabled. Would send to {to_email}: {subject}")
        return True
    
    try:
        msg = mime_multipart.MimeMultipart()
        msg['From'] = SMTP_USERNAME
        msg['To'] = to_email
        msg['Subject'] = subject
        
        msg.attach(mime_text.MimeText(body, 'html'))
        
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(SMTP_USERNAME, SMTP_PASSWORD)
        text = msg.as_string()
        server.sendmail(SMTP_USERNAME, to_email, text)
        server.quit()
        return True
    except Exception as e:
        print(f"Error sending email: {e}")
        return False

def send_registration_notification(user_data, approval_token):
    subject = "New User Registration - Bharath Ladies PG"
    approval_url = url_for('approve_registration', token=approval_token, _external=True)
    
    body = f"""
    <html>
    <body>
        <h2>New User Registration</h2>
        <p>A new user has registered for Bharath Ladies PG Management System:</p>
        
        <table style="border-collapse: collapse; width: 100%;">
            <tr>
                <td style="border: 1px solid #ddd; padding: 8px;"><strong>Username:</strong></td>
                <td style="border: 1px solid #ddd; padding: 8px;">{user_data['username']}</td>
            </tr>
            <tr>
                <td style="border: 1px solid #ddd; padding: 8px;"><strong>Email:</strong></td>
                <td style="border: 1px solid #ddd; padding: 8px;">{user_data['email']}</td>
            </tr>
            <tr>
                <td style="border: 1px solid #ddd; padding: 8px;"><strong>Registration Date:</strong></td>
                <td style="border: 1px solid #ddd; padding: 8px;">{user_data['created_at'].strftime('%Y-%m-%d %H:%M:%S')}</td>
            </tr>
        </table>
        
        <p style="margin-top: 20px;">
            <a href="{approval_url}" 
               style="background-color: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
               Approve Registration
            </a>
        </p>
        
        <p><em>This link will expire in 24 hours.</em></p>
    </body>
    </html>
    """
    
    return send_email(ADMIN_EMAIL, subject, body)

def send_approval_confirmation(user_email, username):
    subject = "Registration Approved - Bharath Ladies PG"
    login_url = url_for('login', _external=True)
    
    body = f"""
    <html>
    <body>
        <h2>Registration Approved!</h2>
        <p>Dear {username},</p>
        <p>Your registration for Bharath Ladies PG Management System has been approved!</p>
        <p>You can now login to your account using your credentials.</p>
        
        <p>
            <a href="{login_url}" 
               style="background-color: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
               Login Now
            </a>
        </p>
        
        <p>Thank you for registering with us!</p>
        <p><em>Bharath Ladies PG Management Team</em></p>
    </body>
    </html>
    """
    
    return send_email(user_email, subject, body)

# Authentication decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        # Validation
        if password != confirm_password:
            flash('Passwords do not match!', 'danger')
            return render_template('register.html')
        
        if users_collection.find_one({'username': username}):
            flash('Username already exists!', 'danger')
            return render_template('register.html')
        
        if users_collection.find_one({'email': email}):
            flash('Email already registered!', 'danger')
            return render_template('register.html')
        
        # Create user with pending approval
        approval_token = secrets.token_urlsafe(32)
        user = {
            'username': username,
            'email': email,
            'password': generate_password_hash(password),
            'is_approved': True,  # Auto-approve all new users
            'approval_token': approval_token,
            'created_at': datetime.now()
        }
        users_collection.insert_one(user)
        
        flash('Registration successful! You can now login with your credentials.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = users_collection.find_one({'username': username})
        
        if user and check_password_hash(user['password'], password):
            session['user_id'] = str(user['_id'])
            session['username'] = user['username']
            flash(f'Welcome back, {username}!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password!', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('home'))

@app.route('/dashboard')
@login_required
def index():
    residents = list(collection.find())
    return render_template('index.html', residents=residents)

@app.route('/add', methods=['GET', 'POST'])
@login_required
def add_resident():
    if request.method == 'POST':
        resident = {
            'name': request.form['name'],
            'contact': request.form['contact'],
            'address': request.form['address'],
            'room_no': request.form['room_no'],
            'rent': float(request.form['rent']),
            'payment_month': request.form['payment_month'],
            'payment_status': request.form.get('payment_status', 'unpaid'),
            'created_at': datetime.now()
        }
        collection.insert_one(resident)
        flash('Resident added successfully!', 'success')
        return redirect(url_for('index'))
    return render_template('add.html')

@app.route('/edit/<resident_id>', methods=['GET', 'POST'])
@login_required
def edit_resident(resident_id):
    if request.method == 'POST':
        updated_data = {
            'name': request.form['name'],
            'contact': request.form['contact'],
            'address': request.form['address'],
            'room_no': request.form['room_no'],
            'rent': float(request.form['rent']),
            'payment_month': request.form['payment_month'],
            'payment_status': request.form.get('payment_status', 'unpaid'),
            'updated_at': datetime.now()
        }
        collection.update_one({'_id': ObjectId(resident_id)}, {'$set': updated_data})
        flash('Resident updated successfully!', 'success')
        return redirect(url_for('index'))
    
    resident = collection.find_one({'_id': ObjectId(resident_id)})
    return render_template('edit.html', resident=resident)

@app.route('/delete/<resident_id>')
@login_required
def delete_resident(resident_id):
    collection.delete_one({'_id': ObjectId(resident_id)})
    flash('Resident deleted successfully!', 'success')
    return redirect(url_for('index'))

@app.route('/toggle_payment/<resident_id>')
@login_required
def toggle_payment(resident_id):
    resident = collection.find_one({'_id': ObjectId(resident_id)})
    if resident:
        current_status = resident.get('payment_status', 'unpaid')
        new_status = 'paid' if current_status != 'paid' else 'unpaid'
        
        collection.update_one(
            {'_id': ObjectId(resident_id)}, 
            {'$set': {'payment_status': new_status, 'updated_at': datetime.now()}}
        )
        flash(f"Payment status updated to {new_status.title()}!", 'success')
    return redirect(url_for('index'))

@app.route('/export_csv')
@login_required
def export_csv():
    residents = list(collection.find())
    
    # Convert ObjectId to string for CSV export
    for resident in residents:
        resident['_id'] = str(resident['_id'])
        if 'created_at' in resident:
            resident['created_at'] = resident['created_at'].strftime('%Y-%m-%d %H:%M:%S')
        if 'updated_at' in resident:
            resident['updated_at'] = resident['updated_at'].strftime('%Y-%m-%d %H:%M:%S')
    
    df = pd.DataFrame(residents)
    
    output = io.StringIO()
    df.to_csv(output, index=False)
    output.seek(0)
    
    response = make_response(output.getvalue())
    response.headers["Content-Disposition"] = f"attachment; filename=bharath_ladies_pg_residents_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    response.headers["Content-type"] = "text/csv"
    
    return response

@app.route('/reports')
@login_required
def reports():
    return render_template('reports.html')

@app.route('/api/rent_data')
@login_required
def rent_data():
    residents = list(collection.find())
    data = {
        'rooms': [str(resident['room_no']) for resident in residents],
        'rents': [resident['rent'] for resident in residents],
        'names': [resident['name'] for resident in residents]
    }
    return jsonify(data)

@app.route('/approve_registration/<token>')
def approve_registration(token):

    user = users_collection.find_one({'approval_token': token, 'is_approved': False})
    
    if not user:
        return render_template('approval_result.html', 
                             success=False, 
                             message="Invalid or expired approval link.")
    
    
    token_age = datetime.now() - user['created_at']
    if token_age.total_seconds() > 86400:  # 24 hours in seconds
        return render_template('approval_result.html', 
                             success=False, 
                             message="Approval link has expired.")
    
    # Approve the user
    users_collection.update_one(
        {'_id': user['_id']}, 
        {'$set': {'is_approved': True}, '$unset': {'approval_token': 1}}
    )
    
    # Send confirmation email to user
    send_approval_confirmation(user['email'], user['username'])
    
    return render_template('approval_result.html', 
                         success=True, 
                         message=f"User '{user['username']}' has been approved successfully! A confirmation email has been sent.")



@app.route('/change_password', methods=['GET', 'POST'])
@login_required
def change_password():
    if request.method == 'POST':
        current_password = request.form['current_password']
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']
        
        user = users_collection.find_one({'_id': ObjectId(session['user_id'])})
        
        if not check_password_hash(user['password'], current_password):
            flash('Current password is incorrect!', 'danger')
            return render_template('change_password.html')
        
        if new_password != confirm_password:
            flash('New passwords do not match!', 'danger')
            return render_template('change_password.html')
        
        if len(new_password) < 6:
            flash('New password must be at least 6 characters long!', 'danger')
            return render_template('change_password.html')
        
        # Update password
        users_collection.update_one(
            {'_id': ObjectId(session['user_id'])},
            {'$set': {'password': generate_password_hash(new_password)}}
        )
        flash('Password changed successfully!', 'success')
        return redirect(url_for('index'))
    
    return render_template('change_password.html')

if __name__ == '__main__':
    app.run(debug=True)