from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def hello_world():
    return render_template("index.html")
    #return "hello world"

@app.route('/about',methods = ['GET'])
def about():
    return render_template("about.html")
    #return "this is my about page"

@app.route('/career',methods = ['GET'])
def service():
    return render_template("services.html")
    #return "this is service page"

@app.route('/contact',methods = ['GET'])
def contact():
    return render_template("contact.html")
    #return "this is contact page"

if __name__ == '__main__':
    app.run()
